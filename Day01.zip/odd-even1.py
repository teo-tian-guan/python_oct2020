num = input("enter a number:")
num = int(num)

if num%2 == 0:
    print("even number")
else:
    print("odd number")
