
#name = input("Enter your name: ")

#print("Your name is " + name)

width = input("enter the width of rectangle:")
height = input("enter the height of rectangle:")

area = float(width) * float(height)
print("the area is " + str(area))
