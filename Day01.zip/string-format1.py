import math

a = math.pi
b = 5
c = 'python'

line = "%s %f %d"%(c, a , b)
print(line)

line = "%05d"%(b)
print(line)